class SocketConfig {
  static const String apiKey = 'YOUR_PUSHER_KEY';
  static const String cluster = 'YOUR_PUSHER_CLUSTER';
  static const bool useTLS = true;
}